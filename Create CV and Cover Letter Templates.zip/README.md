
  # Create CV and Cover Letter Templates

  This is a code bundle for Create CV and Cover Letter Templates. The original project is available at https://www.figma.com/design/i4KmX24v9HvSkwWdxuildS/Create-CV-and-Cover-Letter-Templates.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  